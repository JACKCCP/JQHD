//
//  AppDelegate.h
//  XYPS
//
//  Created by apple on 16/11/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewController.h"

#define appkey    @"548583a6859eafc6508e38ef"
static NSString *channel = @"Publish channel";
static BOOL isProduction = YES ;
#define LLAPPDELEGATE   ((AppDelegate *)[UIApplication sharedApplication].delegate)
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) HomeViewController *home;
- (void)initRootHomeWindow;

@end

