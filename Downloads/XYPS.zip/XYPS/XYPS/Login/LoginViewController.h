//
//  LoginViewController.h
//  XYPS
//
//  Created by apple on 16/11/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController
@property (nonatomic,copy)NSString *registrationID;
@end
