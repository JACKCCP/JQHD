//
//  LoginViewController.m
//  XYPS
//
//  Created by apple on 16/11/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "LoginViewController.h"
#import "HomeViewController.h"
#import "NetWorkingManager.h"
#import "AppDelegate.h"
#import "XTNetworking.h"
#define LLAPPDELEGATE   ((AppDelegate *)[UIApplication sharedApplication].delegate)
@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTextfiled;
@property (weak, nonatomic) IBOutlet UITextField *passWordTextfiled;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
- (IBAction)loginButtonAction:(id)sender;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [_passWordTextfiled setSecureTextEntry:YES];
    
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_userNameTextfiled resignFirstResponder];
    [_passWordTextfiled resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)loginButtonAction:(id)sender {
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"name":self.userNameTextfiled.text,@"password":self.passWordTextfiled.text,@"devicetype":@"4",@"pushcode":[[Singleton shared] getUserRegistID]};
        
        
        [XTNetworking XSNetworkRequestWithURL:HOSTURL parameter:parameter methods:POSTMethodsType successResult:^(id result) {
            NSLog(@"%@------------",result);
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                
                [self showHUDmessage:@"请求成功"];
                [SVProgressHUD dismissWithDelay:1];
                [[Singleton shared] setUserName:_userNameTextfiled.text];
                [[Singleton shared] setPassWord:_passWordTextfiled.text];
                [Singleton shared].isLogin = YES;
                [Singleton shared].roleName = [[result objectForKey:@"data"] objectForKey:@"rolename"];
                [Singleton shared].user_id = [[result objectForKey:@"data"] objectForKey:@"user_id"];
                [Singleton shared].work_name = [[result objectForKey:@"data"] objectForKey:@"name"];
                [Singleton shared].name =  [[result objectForKey:@"data"] objectForKey:@"username"];
                [Singleton shared].headerImgURL =  [[result objectForKey:@"data"] objectForKey:@"pic"];
                
                [((AppDelegate *)[UIApplication sharedApplication].delegate) initRootHomeWindow];
            }
            if ([[result objectForKey:@"result"] integerValue] == 0) {
                [self showHUDmessage:@"您输入的账号或者密码不正确"];
                [SVProgressHUD dismissWithDelay:1];
            }
        } failResult:^(id error) {
            NSLog(@"%@------------",error);
        }];

}
@end
