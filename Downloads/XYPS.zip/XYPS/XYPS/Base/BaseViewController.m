//
//  BaseViewController.m
//  LNDemo
//
//  Created by apple on 16/9/12.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()
{
    MBProgressHUD *_progressHUD;
    
    MBProgressHUD *_whileProgresHUD;
    
    NSTimer *_timer;
}
@end

@implementation BaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

//-(void)back
//{
//    if (self.navigationController.visibleViewController == self) {
//        [self.navigationController popViewControllerAnimated:YES];
//    }
//}

//-(void)backAction
//{
//    [self.navigationController popViewControllerAnimated:YES];
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 20, 30, 40)];
    [backBtn setImage:[UIImage imageNamed:@"backItem"] forState:UIControlStateNormal];
    backBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 5);
    [backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = backItem;
    
//    if (IS_IPHONE6PLUS) {
    
      self.navigationController.navigationBar.translucent = NO;
//    }
    
}
- (void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
    [SVProgressHUD dismiss];
}

- (void)setTitle:(NSString *)title
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 30)];
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setTextAlignment:NSTextAlignmentCenter];
    [titleLabel setText:title];
    [titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18]];
    self.navigationItem.titleView = titleLabel;
}
//SVHUD

- (void)showHUDmessage:(NSString *)message{
    [SVProgressHUD showWithStatus:message];
    [SVProgressHUD setBackgroundColor:[UIColor blackColor]];;
   // [self performSelector:@selector(messageTimeOut) withObject:nil afterDelay:20];
}

//-(void)messageTimeOut{
//    [SVProgressHUD showErrorWithStatus:@"操作超时，请重试"];
 //   [SVProgressHUD dismissWithDelay:1];
//}//
//MBHUD
- (void)showMBHudAndWithMsg:(NSString *)message
{
    if (nil == self.navigationController.view)
    {
        return;
    }
    if (_progressHUD)
    {
        [self hideProgress];
    }
    
    if (_timer)
    {
        [_timer invalidate];
        _timer = nil;
    }
    
    _timer = [NSTimer timerWithTimeInterval:25.0
                                     target:self
                                   selector:@selector(timeoutFailed)
                                   userInfo:nil
                                    repeats:NO];
    [[NSRunLoop currentRunLoop]addTimer:_timer forMode:NSRunLoopCommonModes];
    
    
    _progressHUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    if (message != nil)
    {
        _progressHUD.mode = MBProgressHUDModeIndeterminate;
        _progressHUD.labelText = message;
    }
    
    [_progressHUD show:YES];
    _progressHUD.removeFromSuperViewOnHide = YES;
    [self.navigationController.view addSubview:_progressHUD];
}

- (void)stopMBHudAndWithMsg:(NSString *)message
{
    if (_timer)
    {
        [_timer invalidate];
        _timer = nil;
    }
    
    if (message != nil)
    {
        _progressHUD.mode =  MBProgressHUDModeText;
        _progressHUD.labelText = message;
        [self performSelector:@selector(hideProgress) withObject:nil afterDelay:1.0];
    }
    else
    {
        [self hideProgress];
    }
}

- (void)showMBHudForNetWorkUnavailable
{
    _progressHUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    _progressHUD.mode = MBProgressHUDModeText;
    _progressHUD.labelText = @"抱歉，当前没有网络";
    [_progressHUD show:YES];
    _progressHUD.removeFromSuperViewOnHide = YES;
    [self.navigationController.view addSubview:_progressHUD];
    [self performSelector:@selector(hideProgress) withObject:nil afterDelay:1.0];
}

-(void)showMBHudForStreamUnavailable
{
    _progressHUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    _progressHUD.mode = MBProgressHUDModeText;
    _progressHUD.labelText = @"抱歉，网络异常";
    [_progressHUD show:YES];
    _progressHUD.removeFromSuperViewOnHide = YES;
    [self.navigationController.view addSubview:_progressHUD];
    [self performSelector:@selector(hideProgress) withObject:nil afterDelay:1.0];
}

- (void)hideProgress
{
    if(_progressHUD)
    {
        _progressHUD.hidden = YES;
        _progressHUD  = nil;
    }
}

-(void)timeoutFailed
{
    _progressHUD.mode = MBProgressHUDModeText;
    _progressHUD.labelText = @"操作超时，请重试!";
    [self performSelector:@selector(hideProgress) withObject:nil afterDelay:1.0];
}

- (void)showMBHudAWhile:(NSString *)message
{
    if (!self.navigationController.view)
    {
        return;
    }
    
    if (_whileProgresHUD)
    {
        [self hideWhileProgress];
    }
    
    _whileProgresHUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    _whileProgresHUD.mode = MBProgressHUDModeText;
    _whileProgresHUD.labelText = message;
    [_whileProgresHUD show:YES];
    _whileProgresHUD.removeFromSuperViewOnHide = YES;
    [self.navigationController.view addSubview:_whileProgresHUD];
    [self performSelector:@selector(hideWhileProgress) withObject:nil afterDelay:1.0];
}

- (void)hideWhileProgress
{
    
    if(_whileProgresHUD)
    {
        _whileProgresHUD.hidden = YES;
        _whileProgresHUD  = nil;
    }
}

//动态计算宽高度
- (CGSize)sizeWithTitle:(NSString*)title andFont:(UIFont*)font andSize:(CGSize)size
{
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.alignment = NSLineBreakByWordWrapping;
    NSDictionary *attribute = @{NSFontAttributeName: font, NSParagraphStyleAttributeName: paragraph};
    return [title boundingRectWithSize:size options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
}

- (void)showAlertViewWithMessage:(NSString *)str
{
    UIAlertView *messageAlert = [[UIAlertView alloc] initWithTitle:@"提示"
                                                           message:str
                                                          delegate:self
                                                 cancelButtonTitle:@"确定"
                                                 otherButtonTitles:nil];
    [messageAlert show];
}

//- (UIBarButtonItem *)barButtonItemWithImageName:(NSString *)imageName action:(SEL)action
//{
//    CGRect frame = CGRectMake(0, 0, 30, 25);
//    
//    UIButton *rightBtn= [UIButton buttonWithType:UIButtonTypeCustom];
//    rightBtn.frame = frame;
//    [rightBtn setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
//    rightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
//    [rightBtn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
//    
//    UIBarButtonItem *rightItem=[[UIBarButtonItem alloc]initWithCustomView:rightBtn];
//    rightBtn.exclusiveTouch = YES;
//    
//    return rightItem;
//}
//
//- (UIButton *)setNavRightButtonWithImageName:(NSString *)imageName action:(SEL)action
//{
//    UIBarButtonItem *rightItem = [self barButtonItemWithImageName:imageName action:action];
//    self.navigationItem.rightBarButtonItem = rightItem;
//    return (UIButton *)rightItem.customView;
//}
//
//- (void)setNavLeftButtonWithText:(NSString *)text action:(SEL)action
//{
//    CGRect frame = CGRectMake(0, 0, 50, 25);
//    
//    UIButton *leftBtn= [UIButton buttonWithType:UIButtonTypeCustom];
//    [leftBtn setTitle:text forState:UIControlStateNormal];
//    [leftBtn.titleLabel setFont:[UIFont systemFontOfSize:13.0f]];
//    leftBtn.frame = frame;
//    [leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    leftBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
//    
//    [leftBtn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
//    leftBtn.exclusiveTouch = YES;
//    
//    self.navigationItem.leftBarButtonItem = leftItem;
//}
//
//- (void)setNavRightButtonWithText:(NSString *)text action:(SEL)action
//{
//    CGRect frame = CGRectMake(0, 0, 50, 25);
//    
//    UIButton *rightBtn= [UIButton buttonWithType:UIButtonTypeCustom];
//    [rightBtn setTitle:text forState:UIControlStateNormal];
//    [rightBtn.titleLabel setFont:[UIFont systemFontOfSize:14]];
//    rightBtn.frame = frame;
//    rightBtn.layer.cornerRadius = 2;
//    [rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [rightBtn setBackgroundColor:[UIColor colorWithRed:249/255.0 green:109/255.0 blue:67/255.0 alpha:1.0f]];
//    [rightBtn setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
//    [rightBtn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
//    UIBarButtonItem *rightItem=[[UIBarButtonItem alloc]initWithCustomView:rightBtn];
//    rightBtn.exclusiveTouch = YES;
//    
//    self.navigationItem.rightBarButtonItem = rightItem;
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
