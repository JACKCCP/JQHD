//
//  Singleton.h
//  XYPS
//
//  Created by apple on 16/11/21.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Singleton : NSObject

@property (nonatomic,assign)BOOL isLogin;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *work_name;
@property (nonatomic,copy) NSString *name;
@property (nonatomic, copy) NSString *headerImgURL;
@property (nonatomic,copy) NSString *roleName;
@property (nonatomic,copy) NSString *registrationID;
@property (nonatomic,copy) NSString *onlineState;

+ (Singleton*)shared;
- (BOOL)isValidateNumber:(NSString *)number;
- (UIColor *)colorWithHexString:(NSString *)color;
+ (UIImage*)createImageWithColor:(UIColor*)color;
- (void)cancelPickerView:(UIView *)view;
- (void)setExtraCellLineHidden:(UITableView *)tableView;
- (void)doForIOSTableviewLineWithTableViewCell:(UITableViewCell *)tableViewCell;
- (void)doForIOSTableviewLineWithTableView:(UITableView *)tableview;
- (CGSize)sizeWithString:(NSString *)string font:(UIFont *)font;
+ (NSString*)handleNullString:(id)m_result;
- (void)setUserName:(NSString *)userName;
- (NSString *)getUserName;
- (void)setPassWord:(NSString *)passWord;
- (NSString *)getPassWord;
- (void)setUserRegistID:(NSString *)registID;
- (NSString *)getUserRegistID;
@end
