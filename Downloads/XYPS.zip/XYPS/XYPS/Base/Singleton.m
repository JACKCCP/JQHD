//
//  Singleton.m
//  XYPS
//
//  Created by apple on 16/11/21.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "Singleton.h"
//#define SingletonH(name) + (instancetype)shared##name;
//#define SingletonM(name)

@implementation Singleton
static Singleton *_instance;
+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
_instance = [super allocWithZone:zone];
});
return _instance;
}

+ (Singleton *)shared
{
static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
_instance = [[self alloc] init];
    _instance.isLogin = NO;
    _instance.user_id = @"";
    _instance.headerImgURL = @"";
    _instance.work_name = @"";
    _instance.roleName = @"";
    _instance.name = @"";
    _instance.registrationID = @"";
    _instance.onlineState = @"";
});
return _instance;
}

- (id)copyWithZone:(NSZone *)zone
{
return _instance;
}

- (id)mutableCopyWithZone:(NSZone *)zone {
return _instance;
}

//手机号码正则表达式
- (BOOL)isValidateNumber:(NSString *)number
{
    NSString *regex = @"^(1[3|4|5|7|8][0-9])\\d{8}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL ism = [pred evaluateWithObject:number];
    return ism;
}
//十六进制色值转换UIColor
- (UIColor *)colorWithHexString:(NSString *)color
{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    
    //r
    NSString *rString = [cString substringWithRange:range];
    
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
}

//颜色转成图片
+ (UIImage*)createImageWithColor:(UIColor*)color
{
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

// UIPickerView 取消动画
- (void)cancelPickerView:(UIView *)view
{
    [UIView animateWithDuration:0.3
                     animations:^{
                         view.frame = CGRectMake(view.frame.origin.x, view.frame.origin.y + view.frame.size.height, view.frame.size.width, view.frame.size.height);
                     }
                     completion:^(BOOL finished){
                         [view removeFromSuperview];
                         
                     }];
}

//解决tableview分割线左侧短一部分
- (void)doForIOSTableviewLineWithTableViewCell:(UITableViewCell *)tableViewCell
{
    if ([tableViewCell respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableViewCell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableViewCell respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableViewCell setLayoutMargins:UIEdgeInsetsZero];
    }
    
}

//隐藏tableview多余的分割线
- (void)setExtraCellLineHidden:(UITableView *)tableView
{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor clearColor];
    [tableView setTableFooterView:view];
    [tableView setTableHeaderView:view];
}

- (void)doForIOSTableviewLineWithTableView:(UITableView *)tableview
{
    if ([tableview respondsToSelector:@selector(setSeparatorInset:)]) {
        [tableview setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([tableview respondsToSelector:@selector(setLayoutMargins:)]) {
        [tableview setLayoutMargins:UIEdgeInsetsZero];
    }
    
}

// 定义成方法方便多个label调用 增加代码的复用性
- (CGSize)sizeWithString:(NSString *)string font:(UIFont *)font
{
    CGRect rect = [string boundingRectWithSize:CGSizeMake(320, 8000)//限制最大的宽度和高度
                                       options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading  |NSStringDrawingUsesLineFragmentOrigin//采用换行模式
                                    attributes:@{NSFontAttributeName: font}//传人的字体字典
                                       context:nil];
    
    return rect.size;
}

+ (NSString*)handleNullString:(id)m_result{
    if(m_result==nil){
        return @"";
    }
    if([m_result isEqual:[NSNull null]]){
        return @"";
    }
    return [NSString stringWithFormat:@"%@",m_result];
}

#pragma mark -- 存取用registID
- (void)setUserRegistID:(NSString *)registID
{
    [[NSUserDefaults standardUserDefaults] setObject:registID forKey:@"registID"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString *)getUserRegistID
{
    NSString *registID;
    registID = [[NSUserDefaults standardUserDefaults] objectForKey:@"registID"];
    return registID;
}
#pragma mark -- 存取用户名
- (void)setUserName:(NSString *)userName
{
    [[NSUserDefaults standardUserDefaults] setObject:userName forKey:@"username"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString *)getUserName
{
    NSString *username;
    username = [[NSUserDefaults standardUserDefaults] objectForKey:@"username"];
    return username;
}

#pragma mark -- 存取密码

- (void)setPassWord:(NSString *)passWord
{
    [[NSUserDefaults standardUserDefaults] setObject:passWord forKey:@"password"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (NSString *)getPassWord
{
    NSString *password;
    password = [[NSUserDefaults standardUserDefaults] objectForKey:@"password"];
    return password;
}

@end
