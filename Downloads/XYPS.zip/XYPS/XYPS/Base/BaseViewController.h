//
//  BaseViewController.h
//  LNDemo
//
//  Created by apple on 16/9/12.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController
- (void)back;
//初始化HUD
-(void)showMBHudAndWithMsg:(NSString *)message;

//隐藏HUD（可以添加文字 1秒后消失）
-(void)stopMBHudAndWithMsg:(NSString *)message;

//在没有网络的情况下，先初始化HUD，再1秒后消失。
-(void)showMBHudForNetWorkUnavailable;

//短暂显示HUD，1秒后消失。
- (void)showMBHudAWhile:(NSString *)message;

//设置图片按钮
- (UIButton *)setNavRightButtonWithImageName:(NSString *)imageName action:(SEL)action;

//设置左侧文字按钮
- (void)setNavLeftButtonWithText:(NSString *)text action:(SEL)action;

//设置文字按钮
- (void)setNavRightButtonWithText:(NSString *)text action:(SEL)action;
- (UIBarButtonItem *)barButtonItemWithImageName:(NSString *)imageName action:(SEL)action;

//动态计算宽高度
- (CGSize)sizeWithTitle:(NSString*)title andFont:(UIFont*)font andSize:(CGSize)size;

- (void)showAlertViewWithMessage:(NSString*)str;

- (void)hidesBottomBarWhenPushed:(BOOL)bol;


- (void)showHUDmessage:(NSString *)message;
@end
