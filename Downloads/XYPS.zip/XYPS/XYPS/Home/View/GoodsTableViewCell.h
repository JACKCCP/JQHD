//
//  GoodsTableViewCell.h
//  XYPS
//
//  Created by apple on 16/11/17.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodsTableViewCell : UITableViewCell

@end
