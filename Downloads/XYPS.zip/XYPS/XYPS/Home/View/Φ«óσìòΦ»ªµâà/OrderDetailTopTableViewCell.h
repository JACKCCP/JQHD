//
//  OrderDetailTopTableViewCell.h
//  XYPS
//
//  Created by apple on 16/11/15.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderDetailTopTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *order_NumLabel;
@property (weak, nonatomic) IBOutlet UILabel *order_timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *user_telLabel;
@property (weak, nonatomic) IBOutlet UILabel *adressLabel;

@end
