//
//  DistributeTableViewCell.m
//  XYPS
//
//  Created by apple on 16/11/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "DistributeTableViewCell.h"

@implementation DistributeTableViewCell

- (void)cellIdexpath:(NSUInteger)idexpath name:(NSString *)name user_id:(NSString *)user_id{
    self.number = 0;
    self.number = idexpath;
    self.name = name;
    self.user_id = user_id;
}
- (IBAction)distributeButton:(id)sender {
    NSDictionary *dic = @{@"num":[NSString stringWithFormat:@"%ld",(long)self.number],@"name":self.name,@"user_id":self.user_id};
    [[NSNotificationCenter defaultCenter]postNotificationName:@"distribute" object:dic];
}
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
