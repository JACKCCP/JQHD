//
//  DistributeTableViewCell.h
//  XYPS
//
//  Created by apple on 16/11/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DistributeTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *distributeButton;
@property (assign,nonatomic)NSInteger number;
@property (copy, nonatomic) NSString *name;
@property (copy, nonatomic) NSString *user_id;
- (void)cellIdexpath:(NSUInteger)idexpath name:(NSString *)name user_id:(NSString *)user_id;
@property (weak, nonatomic) IBOutlet UIImageView *nameHeadImage;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *workNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *OnlineLabel;
@property (weak, nonatomic) IBOutlet UILabel *pipeiLabel;
@end
