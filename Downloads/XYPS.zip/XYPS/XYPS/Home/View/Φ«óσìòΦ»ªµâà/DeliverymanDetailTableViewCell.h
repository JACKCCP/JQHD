//
//  DeliverymanDetailTableViewCell.h
//  XYPS
//
//  Created by apple on 16/11/15.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeliverymanDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *storekeeper_nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *work_numAndphone_num;

@end
