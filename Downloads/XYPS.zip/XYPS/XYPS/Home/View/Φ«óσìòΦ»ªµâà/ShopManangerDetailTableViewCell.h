//
//  ShopManangerDetailTableViewCell.h
//  XYPS
//
//  Created by apple on 16/11/15.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopManangerDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *storekeeperLabel;
@property (weak, nonatomic) IBOutlet UILabel *store_workNum_phoneNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *delivery_nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *delivery_workNum_phoneNumLabel;

@end
