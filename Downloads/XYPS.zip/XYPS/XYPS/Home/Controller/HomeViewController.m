//
//  HomeViewController.m
//  XYPS
//
//  Created by apple on 16/11/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "HomeViewController.h"
#import "WorkRecordViewController.h"
#import "WaitListViewController.h"
#import "LoginViewController.h"
#import "HaveOrderViewController.h"
#import "DeliveryViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>

@interface HomeViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIGestureRecognizerDelegate>
{
    NSInteger message;
}
@property (weak, nonatomic) IBOutlet UIButton *WaitingListButton;
@property (weak, nonatomic) IBOutlet UIButton *HaveOrderButton;
@property (weak, nonatomic) IBOutlet UIButton *DeliveryButton;
@property (weak, nonatomic) IBOutlet UIButton *WorkRecordButton;
@property (weak, nonatomic) IBOutlet UILabel *bagade;
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UIButton *loginOutButton;
- (IBAction)loginOutButtonAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *lineButton;
- (IBAction)lineButtonAction:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *workStrLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *workNumLabel;


@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"首页";
    message = 0;
    self.navigationController.navigationBar.translucent = NO;
//    self.WaitingListButton.badgeValue = @"5";
    
    self.bagade.layer.cornerRadius =8;
    self.bagade.layer.shouldRasterize = YES;
    self.workNumLabel.text = [NSString stringWithFormat:@"工作编号：%@", [Singleton shared].work_name];
    self.workStrLabel.text = [NSString stringWithFormat:@"职务：%@", [Singleton shared].roleName];
    self.nameLabel.text = [NSString stringWithFormat:@"姓名：%@", [Singleton shared].name];
    self.headImage.layer.masksToBounds = YES;
    self.headImage.layer.cornerRadius = 40;
    [self.headImage sd_setImageWithURL:[NSURL URLWithString:[Singleton shared].headerImgURL] placeholderImage:[UIImage imageNamed:@"touxiang"]];
    if ([[Singleton shared].roleName isEqualToString:@"库管"]) {
        self.lineButton.hidden = YES;
    }
    
    self.lineButton.backgroundColor = [UIColor colorWithRed:196 /255.0 green:20/255.0 blue:17/255.0 alpha:1];
    [self.lineButton setTitle:@"离线" forState:UIControlStateNormal];
    [self.lineButton setTitle:@"在线" forState:UIControlStateSelected];
    [self.lineButton setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
//    [self initHead];
    if (message == 0) {
        self.bagade.hidden = YES;
    }
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(addNotificationCount) name:@"addNotificationCount" object:nil];
}
- (void)initHead{
    /**
     *  添加手势：也就是当用户点击头像了之后，对这个操作进行反应 
     */
    //允许用户交互
    _headImage.userInteractionEnabled = YES;
    //初始化一个手势
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc]initWithTarget:self
                                                                               action:@selector(alterHeadPortrait:)];
    //给ImageView添加手势
    [_headImage addGestureRecognizer:singleTap];
}
//  方法：alterHeadPortrait
//  方法：alterHeadPortrait
-(void)alterHeadPortrait:(UITapGestureRecognizer *)gesture{
    /**
     *  弹出提示框
     */
    //初始化提示框
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    //按钮：从相册选择，类型：UIAlertActionStyleDefault
    [alert addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //初始化UIImagePickerController
        UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
        //获取方式1：通过相册（呈现全部相册），UIImagePickerControllerSourceTypePhotoLibrary
        //获取方式2，通过相机，UIImagePickerControllerSourceTypeCamera
        //获取方法3，通过相册（呈现全部图片），UIImagePickerControllerSourceTypeSavedPhotosAlbum
        PickerImage.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //允许编辑，即放大裁剪
        PickerImage.allowsEditing = YES;
        //自代理
        PickerImage.delegate = self;
        //页面跳转
        [self presentViewController:PickerImage animated:YES completion:nil];
    }]];
    //按钮：拍照，类型：UIAlertActionStyleDefault
    [alert addAction:[UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        /**
         其实和从相册选择一样，只是获取方式不同，前面是通过相册，而现在，我们要通过相机的方式
         */
        UIImagePickerController *PickerImage = [[UIImagePickerController alloc]init];
        //获取方式:通过相机
        PickerImage.sourceType = UIImagePickerControllerSourceTypeCamera;
        PickerImage.allowsEditing = YES;
        PickerImage.delegate = self;
        [self presentViewController:PickerImage animated:YES completion:nil];
    }]];
    //按钮：取消，类型：UIAlertActionStyleCancel
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}//PickerImage完成后的代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //定义一个newPhoto，用来存放我们选择的图片。
    UIImage *newPhoto = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    //把newPhono设置成头像
    _headImage.image = newPhoto;
    //关闭当前界面，即回到主界面去
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)WaitingListButtonAction:(id)sender {
    WaitListViewController *waitinhg = [[WaitListViewController alloc]initWithNibName:@"WaitListViewController" bundle:[NSBundle mainBundle]];
    waitinhg.title = @"待接单";
    [self.navigationController pushViewController:waitinhg animated:YES];
    message = 0;
    self.bagade.hidden = YES;
}
- (IBAction)HaveOrderButtonAction:(id)sender {
    HaveOrderViewController *haveOrder = [[HaveOrderViewController alloc]initWithNibName:@"HaveOrderViewController" bundle:[NSBundle mainBundle]];
    haveOrder.title = @"已接单";
    [self.navigationController pushViewController:haveOrder animated:YES];
}
- (IBAction)DeliveryButtonAction:(id)sender {
    DeliveryViewController *Delivery = [[DeliveryViewController alloc]initWithNibName:@"DeliveryViewController" bundle:[NSBundle mainBundle]];
    Delivery.title = @"送达";
    [self.navigationController pushViewController:Delivery animated:YES];
}
- (IBAction)WorkRecordButtonAction:(id)sender {
    WorkRecordViewController * WorkRecord = [[WorkRecordViewController alloc]initWithNibName:@"WorkRecordViewController" bundle:[NSBundle mainBundle]];
    WorkRecord.title = @"工作记录";
    [self.navigationController pushViewController: WorkRecord animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (void)addNotificationCount{
    message ++;
    self.bagade.hidden = NO;
    self.bagade.text = [NSString stringWithFormat:@"%ld",(long)message];
    
}

- (IBAction)loginOutButtonAction:(id)sender {
    
    [SVProgressHUD showWithStatus:@"加载中"];
    NSDictionary *parameter = @{@"id":[Singleton shared].user_id,@"online":@"离线"};
    [XTNetworking XSNetworkRequestWithURL:LineState parameter:parameter methods:POSTMethodsType successResult:^(id result) {
        NSLog(@"%@",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
            [SVProgressHUD showSuccessWithStatus:@"请求成功"];
            [SVProgressHUD dismissWithDelay:1];
            self.lineButton.selected = NO;
            [Singleton shared].isLogin = NO;
            [[Singleton shared] setUserName:@""];
            [[Singleton shared] setUser_id:@""];
            [[Singleton shared] setWork_name:@""];
            self.lineButton.backgroundColor = [UIColor colorWithRed:196 /255.0 green:20/255.0 blue:17/255.0 alpha:1];
            LoginViewController *login = [[LoginViewController alloc]initWithNibName:@"LoginViewController" bundle:[NSBundle mainBundle]];
            [self presentViewController:login animated:YES completion:nil];
        }else if([[result objectForKey:@"result"] integerValue] == 0){
            [SVProgressHUD showSuccessWithStatus: @"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [SVProgressHUD showErrorWithStatus:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        
    } failResult:^(id error) {
        NSLog(@"%@",error);
    }];

    
}
- (IBAction)lineButtonAction:(id)sender {
   
    if ( self.lineButton.selected == NO) {
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"id":[Singleton shared].user_id,@"online":@"在线"};
        [XTNetworking XSNetworkRequestWithURL:LineState parameter:parameter methods:POSTMethodsType successResult:^(id result) {
            NSLog(@"%@",result);
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                [SVProgressHUD showSuccessWithStatus:@"请求成功"];
                 [SVProgressHUD dismissWithDelay:1];
                self.lineButton.selected = YES;
                self.lineButton.backgroundColor = [UIColor colorWithRed:18 /255.0 green:199/255.0 blue:0/255.0 alpha:1];
            }else if([[result objectForKey:@"result"] integerValue] == 0){
                [SVProgressHUD showSuccessWithStatus:@"请求数据为空"];
                [SVProgressHUD dismissWithDelay:1];
            }else{
                [SVProgressHUD showErrorWithStatus:@"请求错误"];
                [SVProgressHUD dismissWithDelay:1];
            }
        } failResult:^(id error) {
             NSLog(@"%@",error);
        }];
    }else{
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"id":[Singleton shared].user_id,@"online":@"离线"};
        [XTNetworking XSNetworkRequestWithURL:LineState parameter:parameter methods:POSTMethodsType successResult:^(id result) {
            NSLog(@"%@",result);
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                [SVProgressHUD showSuccessWithStatus:@"请求成功"];
                [SVProgressHUD dismissWithDelay:1];
                self.lineButton.selected = NO;
                self.lineButton.backgroundColor = [UIColor colorWithRed:196 /255.0 green:20/255.0 blue:17/255.0 alpha:1];
            }else if([[result objectForKey:@"result"] integerValue] == 0){
                [SVProgressHUD showSuccessWithStatus: @"请求数据为空"];
                [SVProgressHUD dismissWithDelay:1];
            }else{
                [SVProgressHUD showErrorWithStatus:@"请求错误"];
                [SVProgressHUD dismissWithDelay:1];
            }
            
        } failResult:^(id error) {
             NSLog(@"%@",error);
        }];
    }
}
@end
