//
//  WorkRecordViewController.m
//  XYPS
//
//  Created by apple on 16/11/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "WorkRecordViewController.h"
#import "WorkRecordTableViewCell.h"

static NSInteger dayPage;
static NSInteger weekPage;
static NSInteger lastweekPage;
static NSInteger page;
@interface WorkRecordViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UIButton *toadyBtn;
    UIButton *weekBtn;
    UIButton *monthBtn;
    NSString *timetype;
}
@property (weak, nonatomic) IBOutlet UIView *buttonView;
@property (weak, nonatomic) IBOutlet UITableView *workRecordTableView;
@property (retain,nonatomic) NSMutableArray *dayDataArray;
@property (retain,nonatomic) NSMutableArray *weekDataArray;
@property (retain,nonatomic) NSMutableArray *lastweekDataArray;
@property (retain,nonatomic) NSDictionary *resultDic;
@property (copy,nonatomic) NSString *daycount;
@property (copy,nonatomic) NSString *weekcount;
@property (copy,nonatomic) NSString *allcount;
@property (weak, nonatomic) IBOutlet UILabel *dayCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *weekCoutLabel;
@property (weak, nonatomic) IBOutlet UILabel *allCountLabel;

@end

@implementation WorkRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initButton];
    self.workRecordTableView.delegate = self;
    self.workRecordTableView.dataSource = self;
    [self.workRecordTableView registerNib:[UINib nibWithNibName:@"WorkRecordTableViewCell" bundle:nil] forCellReuseIdentifier:@"WorkRecordTableViewCell"];
     self.workRecordTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.dayDataArray = [NSMutableArray arrayWithCapacity:30];
    self.weekDataArray = [NSMutableArray arrayWithCapacity:30];
    self.lastweekDataArray = [NSMutableArray arrayWithCapacity:30];
    dayPage = 1;
    weekPage = 1;
    lastweekPage = 1;
    page = 0;
    toadyBtn.selected = YES;
    timetype = @"1";
    [self headerBeginRefresh];
    
   
}

- (void)headerBeginRefresh{
    self.workRecordTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        // 进入刷新状态后会自动调用这个block
    }];
    // 或
    // 设置回调（一旦进入刷新状态，就调用 target 的 action，也就是调用 self 的 loadNewData 方法）
    self.workRecordTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewData)];
    // 马上进入刷新状态
    [self.workRecordTableView.mj_header beginRefreshing];
    [self footerBeginRefresh];
    
}
- (void)footerBeginRefresh{
  
    self.workRecordTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        // 进入刷新状态后会自动调用这个 block
        
    }];
    // 或
    // 设置回调（一旦进入刷新状态，就调用 target 的 action，即调用 self 的 loadMoreData 方法）
    self.workRecordTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
}
/**
 * 更新视图.
 */
- (void) updateView
{
    [self.workRecordTableView reloadData];
}
/**
 *  停止刷新
 */
-(void)endRefresh{
    [self.workRecordTableView.mj_header endRefreshing];
    [self.workRecordTableView.mj_footer endRefreshing];
}
/**
 *  更新数据.
 *
 *  数据更新后,会自动更新视图.
 */
- (void)loadMoreData{
    if (toadyBtn.selected == YES) {
        page = 0;
        dayPage++;
      page = dayPage;
        timetype = @"1";
    }
    if (weekBtn.selected == YES) {
        timetype = @"2";
        page = 0;
        weekPage++;
        page = weekPage;
    }
    if (monthBtn.selected == YES) {
        timetype = @"3";
        page = 0;
        lastweekPage++;
        page = lastweekPage;
    }
    [SVProgressHUD showWithStatus:@"加载中"];
    
    NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":timetype,@"page":[NSString stringWithFormat:@"%ld",(long)page]};
    
    [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
        NSLog(@"%@------------",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
            [self showHUDmessage:@"请求成功"];
              [SVProgressHUD dismissWithDelay:1];
            if ([timetype isEqualToString:@"1"]) {
                [self.dayDataArray addObjectsFromArray:[result objectForKey:@"data"]];
            }
            if ([timetype isEqualToString:@"2"]) {
                [self.weekDataArray addObjectsFromArray:[result objectForKey:@"data"]];
            }
            if ([timetype isEqualToString:@"3"]) {
                [self.lastweekDataArray addObjectsFromArray:[result objectForKey:@"data"]];
            }
            
            self.daycount = [result objectForKey:@"datenum"];
            self.weekcount = [result objectForKey:@"weeknum"];
            self.allcount = [result objectForKey:@"all"];
            self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
            self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
            self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
            [self endRefresh];
        }else if([[result objectForKey:@"result"] integerValue] == 0){
            [self showHUDmessage:@"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [self showHUDmessage:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        
        [self endRefresh];
        [self.workRecordTableView reloadData];
    } failResult:^(id error) {
        NSLog(@"%@------------",error);
    }];
}
- (void)loadNewData{
    if (toadyBtn.selected == YES) {
        timetype = @"1";
  
    }
    if (weekBtn.selected == YES) {
        timetype = @"2";
    }
    if (monthBtn.selected == YES) {
        timetype = @"3";
    }
    [self.dayDataArray removeAllObjects];
    [self.weekDataArray removeAllObjects];
    [self.lastweekDataArray removeAllObjects];
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":timetype,@"page":@"1"};
        
        [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
            NSLog(@"%@------------",result);
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                [self showHUDmessage:@"请求成功"];
                  [SVProgressHUD dismissWithDelay:1];
                
                if ([timetype isEqualToString:@"1"]) {
                    [self.dayDataArray addObjectsFromArray:[result objectForKey:@"data"]];
                }
                if ([timetype isEqualToString:@"2"]) {
                    [self.weekDataArray addObjectsFromArray:[result objectForKey:@"data"]];
                }
                if ([timetype isEqualToString:@"3"]) {
                    [self.lastweekDataArray addObjectsFromArray:[result objectForKey:@"data"]];
                }
                self.daycount = [result objectForKey:@"datenum"];
                self.weekcount = [result objectForKey:@"weeknum"];
                self.allcount = [result objectForKey:@"all"];
                self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
                self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
                self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
            }else if([[result objectForKey:@"result"] integerValue] == 0){
                [self showHUDmessage:@"请求数据为空"];
                [SVProgressHUD dismissWithDelay:1];
            }else{
                [self showHUDmessage:@"请求错误"];
                [SVProgressHUD dismissWithDelay:1];
            }
            [self endRefresh];
            [self.workRecordTableView reloadData];
        } failResult:^(id error) {
            NSLog(@"%@------------",error);
        }];
    
   
}

//- (void)netWork{
//    [SVProgressHUD showWithStatus:@"加载中"];
//    NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":@"1",@"page":[NSString stringWithFormat:@"%ld",(long)dayPage]};
//   
//    [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
//        NSLog(@"%@------------",result);
//        if ([[result objectForKey:@"result"] integerValue] == 1) {
//               [self showHUDmessage:@"请求成功"];
//               [SVProgressHUD dismissWithDelay:1];
//            [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
//            self.daycount = [result objectForKey:@"datenum"];
//            self.weekcount = [result objectForKey:@"weeknum"];
//            self.allcount = [result objectForKey:@"all"];
//            self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
//            self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
//            self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
//            [self headerBeginRefresh];
//        }else if([[result objectForKey:@"result"] integerValue] == 0){
//            [self showHUDmessage:@"请求数据为空"];
//            [SVProgressHUD dismissWithDelay:1];
//        }else{
//            [self showHUDmessage:@"请求错误"];
//            [SVProgressHUD dismissWithDelay:1];
//        }
//        
//        [self.workRecordTableView reloadData];
//    } failResult:^(id error) {
//        NSLog(@"%@------------",error);
//    }];
//}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (toadyBtn. selected == YES) {
        return self.dayDataArray.count;
    }
    if (weekBtn. selected == YES) {
        return self.weekDataArray.count;
    }
    if (monthBtn.selected == YES) {
        return self.lastweekDataArray.count;
    }
    return 1;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"WorkRecordTableViewCell";
    
    WorkRecordTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell =  [[WorkRecordTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (toadyBtn. selected == YES) {
        NSString *numStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"ordernum"];
        cell.order_numLabel.text = [NSString stringWithFormat:@"订单编号：%@",numStr];
        NSString *startStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"pstimes"];
        cell.order_startLaebl.text = [NSString stringWithFormat:@"配送时间：%@",startStr];
        NSString *stopStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"sdtimes"];
        cell.order_stopTimeLabel.text = [NSString stringWithFormat:@"送达时间：%@",stopStr];
        NSString *deliveryStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"psname"];
        cell.delivery_manLabel.text = [NSString stringWithFormat:@"配送人：%@",deliveryStr];
        NSString *reciverStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"shname"];
        cell.reciver_manLabel.text = [NSString stringWithFormat:@"收货人：%@",reciverStr];
        NSString *accountStr = [[self.dayDataArray objectAtIndex:indexPath.row]objectForKey:@"price"];
        cell.accontLabel.text = [NSString stringWithFormat:@"金额：%@",accountStr];
    }
    if (weekBtn. selected == YES) {
        NSString *numStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"ordernum"];
        cell.order_numLabel.text = [NSString stringWithFormat:@"订单编号：%@",numStr];
        NSString *startStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"pstimes"];
        cell.order_startLaebl.text = [NSString stringWithFormat:@"配送时间：%@",startStr];
        NSString *stopStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"sdtimes"];
        cell.order_stopTimeLabel.text = [NSString stringWithFormat:@"送达时间：%@",stopStr];
        NSString *deliveryStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"psname"];
        cell.delivery_manLabel.text = [NSString stringWithFormat:@"配送人：%@",deliveryStr];
        NSString *reciverStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"shname"];
        cell.reciver_manLabel.text = [NSString stringWithFormat:@"收货人：%@",reciverStr];
        NSString *accountStr = [[self.weekDataArray objectAtIndex:indexPath.row]objectForKey:@"price"];
        cell.accontLabel.text = [NSString stringWithFormat:@"金额：%@",accountStr];
    }
    if (monthBtn.selected == YES) {
        NSString *numStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"ordernum"];
        cell.order_numLabel.text = [NSString stringWithFormat:@"订单编号：%@",numStr];
        NSString *startStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"pstimes"];
        cell.order_startLaebl.text = [NSString stringWithFormat:@"配送时间：%@",startStr];
        NSString *stopStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"sdtimes"];
        cell.order_stopTimeLabel.text = [NSString stringWithFormat:@"送达时间：%@",stopStr];
        NSString *deliveryStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"psname"];
        cell.delivery_manLabel.text = [NSString stringWithFormat:@"配送人：%@",deliveryStr];
        NSString *reciverStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"shname"];
        cell.reciver_manLabel.text = [NSString stringWithFormat:@"收货人：%@",reciverStr];
        NSString *accountStr = [[self.lastweekDataArray objectAtIndex:indexPath.row]objectForKey:@"price"];
        cell.accontLabel.text = [NSString stringWithFormat:@"金额：%@",accountStr];
    }
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 140;
}
- (void)initButton{
    weekBtn = [[UIButton alloc] initWithFrame:CGRectMake(kMainScreenWidth/3, 0, kMainScreenWidth/3, 40)];
    weekBtn.tag = 13;
    [weekBtn setTitle:@"本周" forState:UIControlStateNormal];
    [[weekBtn titleLabel] setFont:[UIFont systemFontOfSize:15]];
    [weekBtn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [weekBtn setTitleColor:TEXTCOLOR forState:UIControlStateSelected];
    [weekBtn addTarget:self action:@selector(clickedTabButtons:) forControlEvents:UIControlEventTouchUpInside];
    [_buttonView addSubview:weekBtn];
    
    UILabel *line1 = [[UILabel alloc] initWithFrame:CGRectMake(kMainScreenWidth/3-1, 8, .8, 24)];
    [line1 setBackgroundColor:[UIColor lightGrayColor]];
    [_buttonView addSubview:line1];
    
    monthBtn = [[UIButton alloc] initWithFrame:CGRectMake(kMainScreenWidth/3*2, 0, kMainScreenWidth/3, 40)];
    monthBtn.tag = 14;
    [monthBtn setTitle:@"上周" forState:UIControlStateNormal];
    [[monthBtn titleLabel] setFont:[UIFont systemFontOfSize:15]];
    [monthBtn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [monthBtn setTitleColor:TEXTCOLOR forState:UIControlStateSelected];
    [monthBtn addTarget:self action:@selector(clickedTabButtons:) forControlEvents:UIControlEventTouchUpInside];
    [_buttonView addSubview:monthBtn];
    
    UILabel *line2 = [[UILabel alloc] initWithFrame:CGRectMake(kMainScreenWidth/3*2-1, 8, .8, 24)];
    [line2 setBackgroundColor:[UIColor lightGrayColor]];
    [_buttonView addSubview:line2];
    
    toadyBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kMainScreenWidth/3, 40)];
    [toadyBtn setSelected:YES];
    toadyBtn.tag = 12;
    [toadyBtn setTitle:@"今日" forState:UIControlStateNormal];
    [[toadyBtn titleLabel] setFont:[UIFont systemFontOfSize:15]];
    [toadyBtn setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [toadyBtn setTitleColor:TEXTCOLOR forState:UIControlStateSelected];
    [toadyBtn addTarget:self action:@selector(clickedTabButtons:) forControlEvents:UIControlEventTouchUpInside];
    [_buttonView addSubview:toadyBtn];
}
- (void)clickedTabButtons:(UIButton *)button
{
    if (button.tag == 12) {
        [weekBtn setSelected:NO];
        [toadyBtn setSelected:YES];
        [monthBtn setSelected:NO];
        [self.dayDataArray removeAllObjects];
        [self.lastweekDataArray removeAllObjects];
        [self.workRecordTableView reloadData];
        [self headerBeginRefresh];
//        [SVProgressHUD showWithStatus:@"加载中"];
//        NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":@"1",@"page":[NSString stringWithFormat:@"%ld",(long)dayPage]};
//    
//        [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
//            NSLog(@"%@------------",result);
//            if ([[result objectForKey:@"result"] integerValue] == 1) {
//                 [self showHUDmessage:@"请求成功"];
//                 [SVProgressHUD dismissWithDelay:1];
//                [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
//                self.daycount = [result objectForKey:@"datenum"];
//                self.weekcount = [result objectForKey:@"weeknum"];
//                self.allcount = [result objectForKey:@"all"];
//                self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
//                self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
//                self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
//            }else if([[result objectForKey:@"result"] integerValue] == 0){
//                [self showHUDmessage:@"请求数据为空"];
//                [SVProgressHUD dismissWithDelay:1];
//            }else{
//                [self showHUDmessage:@"请求错误"];
//                [SVProgressHUD dismissWithDelay:1];
//            }
//            
//            [self.workRecordTableView reloadData];
//        } failResult:^(id error) {
//            NSLog(@"%@------------",error);
//        }];
    }
    if (button.tag == 13) {
        [weekBtn setSelected:YES];
        [toadyBtn setSelected:NO];
        [monthBtn setSelected:NO];
      
//        [SVProgressHUD showWithStatus:@"加载中"];
//        weekPage = 1;
//        NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":@"2",@"page":[NSString stringWithFormat:@"%ld",(long)weekPage]};
//      
//        [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
//            NSLog(@"%@------------",result);
//            if ([[result objectForKey:@"result"] integerValue] == 1) {
//                [self showHUDmessage:@"请求成功"];
//                  [SVProgressHUD dismissWithDelay:1];
//                [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
//                self.daycount = [result objectForKey:@"datenum"];
//                self.weekcount = [result objectForKey:@"weeknum"];
//                self.allcount = [result objectForKey:@"all"];
//                self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
//                self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
//                self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
        [self.dayDataArray removeAllObjects];
        [self.lastweekDataArray removeAllObjects];
        [self.workRecordTableView reloadData];
                [self headerBeginRefresh];
//            }else if([[result objectForKey:@"result"] integerValue] == 0){
//                [self showHUDmessage:@"请求数据为空"];
//                [SVProgressHUD dismissWithDelay:1];
//            }else{
//                [self showHUDmessage:@"请求错误"];
//                [SVProgressHUD dismissWithDelay:1];
//            }
//            
//            [self.workRecordTableView reloadData];
//        } failResult:^(id error) {
//            NSLog(@"%@------------",error);
//        }];
    }
    if (button.tag == 14) {
        [weekBtn setSelected:NO];
        [toadyBtn setSelected:NO];
        [monthBtn setSelected:YES];
        [self.dayDataArray removeAllObjects];
        [self.lastweekDataArray removeAllObjects];
        [self.workRecordTableView reloadData];
         [self headerBeginRefresh];
//        [SVProgressHUD showWithStatus:@"加载中"];
//        NSDictionary *parameter = @{@"user_id":[Singleton shared].user_id,@"timetype ":@"3",@"page":[NSString stringWithFormat:@"%ld",(long)lastweekPage]};
//        [XTNetworking XSNetworkRequestWithURL:WorkLog parameter:parameter methods:POSTMethodsType successResult:^(id result) {
//            NSLog(@"%@------------",result);
//            if ([[result objectForKey:@"result"] integerValue] == 1) {
//                  [self showHUDmessage:@"请求成功"];
//                   [SVProgressHUD dismissWithDelay:1];
//                [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
//                self.daycount = [result objectForKey:@"datenum"];
//                self.weekcount = [result objectForKey:@"weeknum"];
//                self.allcount = [result objectForKey:@"all"];
//                self.dayCountLabel.text = [NSString stringWithFormat:@"本日工作次数：%@次",self.daycount];
//                self.weekCoutLabel.text = [NSString stringWithFormat:@"本周工作次数：%@次",self.weekcount];
//                self.allCountLabel.text = [NSString stringWithFormat:@"总额：%@元",self.allcount];
//            }else if([[result objectForKey:@"result"] integerValue] == 0){
//                [self showHUDmessage:@"请求数据为空"];
//                [SVProgressHUD dismissWithDelay:1];
//            }else{
//                [self showHUDmessage:@"请求错误"];
//                [SVProgressHUD dismissWithDelay:1];
//            }
//            
//            [self.workRecordTableView reloadData];
//        } failResult:^(id error) {
//            NSLog(@"%@------------",error);
//        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
