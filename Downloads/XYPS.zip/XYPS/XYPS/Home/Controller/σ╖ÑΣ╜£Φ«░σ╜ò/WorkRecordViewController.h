//
//  WorkRecordViewController.h
//  XYPS
//
//  Created by apple on 16/11/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface WorkRecordViewController : BaseViewController

@end
