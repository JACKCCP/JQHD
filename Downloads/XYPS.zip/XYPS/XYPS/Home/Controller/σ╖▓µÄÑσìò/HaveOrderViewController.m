//
//  HaveOrderViewController.m
//  XYPS
//
//  Created by apple on 16/11/11.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "HaveOrderViewController.h"
#import "HaveOrderDetailViewController.h"
#import "ComonTableViewCell.h"

@interface HaveOrderViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSString *user_id;
}
@property (weak, nonatomic) IBOutlet UITableView *haveOrderTableView;
@property (nonatomic,retain) NSMutableArray *dataArray;
@end

@implementation HaveOrderViewController
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.haveOrderTableView.delegate = self;
    self.haveOrderTableView.dataSource = self;
    self.haveOrderTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.haveOrderTableView registerNib:[UINib nibWithNibName:@"ComonTableViewCell" bundle:nil] forCellReuseIdentifier:@"ComonTableViewCell"];
    
    self.dataArray = [NSMutableArray arrayWithCapacity:30];
    user_id = [Singleton shared].user_id;
    [self netWorking];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(recieveNetAction:) name:@"recieveNet" object:nil
     ];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(succeedAction:) name:@"succeed" object:nil
     ];
    
}
- (void)succeedAction:(NSNotification *)notifaction{
   
    [self.dataArray removeAllObjects];
    [self netWorking];
}
- (void)recieveNetAction:(NSNotification *)notifaction{
    
    [self.dataArray removeAllObjects];
    [self netWorking];
}
- (void)netWorking{
    [SVProgressHUD showWithStatus:@"加载中"];
    NSDictionary *parameter = @{@"user_id":user_id,@"ordertype":@"已接单"};
    [XTNetworking XSNetworkRequestWithURL:HaveOrder parameter:parameter methods:POSTMethodsType successResult:^(id result) {
        NSLog(@"%@------------",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
            
            [self showHUDmessage:@"请求成功"];
             [SVProgressHUD dismissWithDelay:1];
            NSDictionary *dic = [result objectForKey:@"data"];
            [self.dataArray addObjectsFromArray: [dic objectForKey:@"datalist"]];
        }else if([[result objectForKey:@"result"] integerValue] == 0){
            [self showHUDmessage:@"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [self showHUDmessage:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        
        [self.haveOrderTableView reloadData];
    } failResult:^(id error) {
        NSLog(@"%@---",error);
    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"ComonTableViewCell";
    
    ComonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell =  [[ComonTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    NSString *numberStr = [[self.dataArray objectAtIndex:indexPath.row] objectForKey: @"ordernum"];
    cell.order_numLabel.text = [NSString stringWithFormat:@"订单编号：%@",numberStr];
    NSString *timeStr = [[self.dataArray objectAtIndex:indexPath.row] objectForKey: @"times"];
    cell.order_timeLabel.text = [NSString stringWithFormat:@"订单时间：%@",timeStr];
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (IS_IPHONE5) {
        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
        return cell.frame.size.height;
//    }else{
//        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
//        return cell.frame.size.height/568 *kMainScreenHeight;
//    }
   
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *order_id =  [[self.dataArray objectAtIndex:indexPath.row] objectForKey: @"order_id"];
    NSString *numberStr = [[self.dataArray objectAtIndex:indexPath.row] objectForKey: @"ordernum"];
    NSString *timeStr = [[self.dataArray objectAtIndex:indexPath.row] objectForKey: @"times"];
    HaveOrderDetailViewController *detail = [[HaveOrderDetailViewController alloc]initWithNibName:@"HaveOrderDetailViewController" bundle:[NSBundle mainBundle]];
    detail.order_id = order_id;
    detail.order_num = numberStr;
    detail.order_time = timeStr;
    detail.index = indexPath.row;
    [self.navigationController pushViewController:detail animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
