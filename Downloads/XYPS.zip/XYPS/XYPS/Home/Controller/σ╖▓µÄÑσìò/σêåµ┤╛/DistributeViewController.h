//
//  DistributeViewController.h
//  XYPS
//
//  Created by apple on 16/11/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface DistributeViewController : BaseViewController
@property (nonatomic,copy)NSString *oreder_id;
@property (nonatomic,assign)NSInteger index;
@end
