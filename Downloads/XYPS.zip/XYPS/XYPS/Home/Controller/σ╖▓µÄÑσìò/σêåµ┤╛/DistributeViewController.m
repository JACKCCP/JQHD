//
//  DistributeViewController.m
//  XYPS
//
//  Created by apple on 16/11/18.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "DistributeViewController.h"
#import "DistributeTableViewCell.h"
#import "DeliveryViewController.h"
#import "Singleton.h"
@interface DistributeViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSString *roleName;
    NSString *user_self_id;
    NSString *user_id;
    NSString *name;
}
@property (weak, nonatomic) IBOutlet UITableView *distributeTableView;
@property (nonatomic,retain) NSMutableArray *dataArray;

@property (nonatomic,copy) NSString *workStr;

@end

@implementation DistributeViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title =@"分派";
    self.dataArray = [NSMutableArray arrayWithCapacity:30];
    self.distributeTableView.delegate = self;
    self.distributeTableView.dataSource = self;
    self.distributeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.distributeTableView registerNib:[UINib nibWithNibName:@"DistributeTableViewCell" bundle:nil] forCellReuseIdentifier:@"DistributeTableViewCell"];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notifacationAction:) name:@"distribute" object:nil];
    roleName = [Singleton shared].roleName;
    user_self_id = [Singleton shared].user_id;
    
    [self netWorking];
    
    
}
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)netWorking{
    
    if ([roleName isEqualToString:@"库管"]) {
        [SVProgressHUD showWithStatus:@"加载中"];
        [XTNetworking XSNetworkRequestWithURL:deliverList  parameter:nil methods:POSTMethodsType successResult:^( id result) {
            NSLog(@"%@------------",result);
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                 [self showHUDmessage:@"请求成功"];
                    [SVProgressHUD dismissWithDelay:1];
                [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
                
            }else if([[result objectForKey:@"result"] integerValue] == 0){
                [self showHUDmessage:@"请求数据为空"];
                [SVProgressHUD dismissWithDelay:1];
            }else{
                [self showHUDmessage:@"请求错误"];
                [SVProgressHUD dismissWithDelay:1];
            }
            [self.distributeTableView reloadData];
        } failResult:^(id error) {
            NSLog(@"%@------------",error);
        }];
    }
    if ([roleName isEqualToString:@"配送员"]) {
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"order_id":self.oreder_id};
    [XTNetworking XSNetworkRequestWithURL:managerList  parameter:parameter methods:POSTMethodsType successResult:^( id result) {
        NSLog(@"%@------------",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
   
             [self showHUDmessage:@"请求成功"];
                [SVProgressHUD dismissWithDelay:1];
           [self.dataArray addObjectsFromArray:[result objectForKey:@"data"]];
            
        }else if([[result objectForKey:@"result"] integerValue] == 0){
            [self showHUDmessage:@"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [self showHUDmessage:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        [self.distributeTableView reloadData];
    } failResult:^(id error) {
        NSLog(@"%@------------",error);
    }];
    }

}
- (void)notifacationAction:(NSNotification*) notification{
    NSDictionary *dic = [notification object];
//    NSLog(@"%@",str);
    name = [dic objectForKey:@"name"];
    user_id = [dic objectForKey:@"user_id"];
    [self showOkayCancelAlert];
    
    
}
- (void)showOkayCancelAlert {
    NSString *title = NSLocalizedString(@"是否派送给", nil);
    NSString *message = NSLocalizedString(name, nil);
    NSString *cancelButtonTitle = NSLocalizedString(@"取消", nil);
    NSString *otherButtonTitle = NSLocalizedString(@"确定", nil);
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    // Create the actions.
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        NSLog(@"The \"Okay/Cancel\" alert's cancel action occured.");
    }];
    
    UIAlertAction *otherAction = [UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [SVProgressHUD showWithStatus:@"加载中"];
        NSDictionary *parameter = @{@"user_self_id":user_self_id,@"order_id":self.oreder_id,@"user_id":user_id};
        [XTNetworking XSNetworkRequestWithURL:Fenpai parameter: parameter methods:POSTMethodsType successResult:^(id result) {
            if ([[result objectForKey:@"result"] integerValue] == 1) {
                NSLog(@"%@------",result);
                NSMutableArray *viewsArray = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                [viewsArray removeObjectAtIndex:viewsArray.count - 2];
                [self.navigationController setViewControllers:viewsArray];
                [[NSNotificationCenter defaultCenter]postNotificationName:@"succeed" object:nil];
                [self.navigationController popViewControllerAnimated:NO];
                [SVProgressHUD showSuccessWithStatus:@"分派成功"];
                [SVProgressHUD dismissWithDelay:1];
            }else if([[result objectForKey:@"result"] integerValue] == 0){
                [self showHUDmessage:@"请求数据为空"];
                [SVProgressHUD dismissWithDelay:1];
            }else{
                [self showHUDmessage:@"请求错误"];
                [SVProgressHUD dismissWithDelay:1];
            }
        
        } failResult:^(id error) {
            
        }];
    }];
    
    // Add the actions.
    [alertController addAction:cancelAction];
    [alertController addAction:otherAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"DistributeTableViewCell";
    
    DistributeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell =  [[DistributeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    NSString *nameStr  = [[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"username"];
    cell.nameLabel.text = [NSString stringWithFormat:@"姓名: %@",nameStr];
    NSString *workStr  = [[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"name"];
    cell.workNumLabel.text = [NSString stringWithFormat:@"工作编号:%@",workStr];
    [cell.nameHeadImage sd_setImageWithURL:[NSURL URLWithString: [[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"pic"]] placeholderImage:nil];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell cellIdexpath:indexPath.row name:nameStr user_id:[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"user_id"]];
    cell.OnlineLabel.text = [[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"online"];
    if ( [[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"online"] isEqualToString:@"在线"]) {
        cell.OnlineLabel.textColor  = [UIColor colorWithRed:18 /255.0 green:199/255.0 blue:0/255.0 alpha:1];
    }
    if ([[[self.dataArray objectAtIndex:indexPath.row] objectForKey:@"pipei"] integerValue ] == 1) {
        cell.pipeiLabel.text = @"优先匹配";
    }else{
         cell.pipeiLabel.text = @"";
    }
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    if (IS_IPHONE5) {
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
    //    }else{
    //        UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    //        return cell.frame.size.height/568 *kMainScreenHeight;
    //    }
    //    return 80;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
