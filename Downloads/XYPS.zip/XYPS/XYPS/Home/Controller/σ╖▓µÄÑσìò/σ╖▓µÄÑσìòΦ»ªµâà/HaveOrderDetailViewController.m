//
//  HaveOrderDetailViewController.m
//  XYPS
//
//  Created by apple on 16/11/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "HaveOrderDetailViewController.h"
#import "OrderDetailTopTableViewCell.h"
#import "DeliverymanDetailTableViewCell.h"
#import "SongdaDetailTableViewCell.h"
#import "ShopManangerDetailTableViewCell.h"
#import "GoodsTableViewCell.h"
#import "GoodsListTableViewCell.h"
#import "DistributeViewController.h"
#import "SongdaDetailTableViewCell.h"

@interface HaveOrderDetailViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSString *user_id;
    NSString *roleName;
}
@property (weak, nonatomic) IBOutlet UITableView *haveOrderDetailTableView;
@property(nonatomic,copy)NSString *workStr;
@property(nonatomic,copy)NSString *schoolStr;
@property (weak, nonatomic) IBOutlet UIButton *distributtonButton;
@property (weak, nonatomic) IBOutlet UIButton *songdaButton;
- (IBAction)songdaButtonAction:(id)sender;
@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSMutableArray *userArray;
@property (nonatomic,retain) NSMutableDictionary *resultDic;

@end

@implementation HaveOrderDetailViewController
-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (IBAction)distributtonAction:(id)sender {
    DistributeViewController *Distribute = [[DistributeViewController alloc]initWithNibName:@"DistributeViewController" bundle:[NSBundle mainBundle]];
    Distribute.oreder_id = self.order_id;
    Distribute.index = self.index;
    [self.navigationController pushViewController:Distribute  animated:YES];
    
}

- (IBAction)songdaButtonAction:(id)sender {
    [SVProgressHUD showWithStatus:@"加载中"];
     NSDictionary *parameter = @{@"order_id":self.order_id,@"user_id":user_id};
    [XTNetworking XSNetworkRequestWithURL:SongdaButton  parameter:parameter methods:POSTMethodsType successResult:^( id result) {
        NSLog(@"%@------------",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
            [self showHUDmessage:@"请求成功"];
            [SVProgressHUD dismissWithDelay:1];
            [self.navigationController popViewControllerAnimated:YES];
            [[NSNotificationCenter defaultCenter]postNotificationName:@"recieveNet" object:nil];
        }
         else if([[result objectForKey:@"result"] integerValue] == 0){
            [self showHUDmessage:@"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [self showHUDmessage:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        [self.haveOrderDetailTableView reloadData];
    } failResult:^(id error) {
        NSLog(@"%@------------",error);
        
        
    }];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"已接单详情";
        self.haveOrderDetailTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.haveOrderDetailTableView.delegate = self;
    self.haveOrderDetailTableView.dataSource = self;
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"GoodsTableViewCell" bundle:nil] forCellReuseIdentifier:@"GoodsTableViewCell"];
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"GoodsListTableViewCell" bundle:nil] forCellReuseIdentifier:@"GoodsListTableViewCell"];
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"OrderDetailTopTableViewCell" bundle:nil] forCellReuseIdentifier:@"OrderDetailTopTableViewCell"];
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"DeliverymanDetailTableViewCell" bundle:nil] forCellReuseIdentifier:@"DeliverymanDetailTableViewCell"];
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"ShopManangerDetailTableViewCell" bundle:nil] forCellReuseIdentifier:@"ShopManangerDetailTableViewCell"];
    [self.haveOrderDetailTableView registerNib:[UINib nibWithNibName:@"SongdaDetailTableViewCell" bundle:nil] forCellReuseIdentifier:@"SongdaDetailTableViewCell"];
    
  
    user_id = [Singleton shared].user_id;
    roleName = [Singleton shared].roleName;
    if ([roleName isEqualToString:@"店长"]) {
        self.distributtonButton.hidden = YES;
    }
    if ( [roleName isEqualToString:@"库管"]) {
        
        self.songdaButton.hidden = YES;
    }
    self.dataArray = [NSMutableArray arrayWithCapacity:30];
    self.userArray = [NSMutableArray arrayWithCapacity:30];
    
    [self netWorking];
}

- (void)netWorking{
    [SVProgressHUD showWithStatus:@"加载中"];
    NSDictionary *parameter = @{@"order_id":self.order_id,@"user_id":user_id,@"rolename":[Singleton shared].roleName};
    [XTNetworking XSNetworkRequestWithURL:HaveOrderDetail  parameter:parameter methods:POSTMethodsType successResult:^( id result) {
       // NSLog(@"%@------------",result);
        if ([[result objectForKey:@"result"] integerValue] == 1) {
            [SVProgressHUD showWithStatus:@"加载中"];
             [self showHUDmessage:@"请求成功"];
               [SVProgressHUD dismissWithDelay:1];
            self.resultDic = [result objectForKey:@"data"];
            self.dataArray = [self.resultDic objectForKey:@"datalist"];
           [ self.userArray addObjectsFromArray:[self.resultDic objectForKey:@"userlist"]];
        }else if([[result objectForKey:@"result"] integerValue] == 0){
            [self showHUDmessage:@"请求数据为空"];
            [SVProgressHUD dismissWithDelay:1];
        }else{
            [self showHUDmessage:@"请求错误"];
            [SVProgressHUD dismissWithDelay:1];
        }
        [self.haveOrderDetailTableView reloadData];
    } failResult:^(id error) {
        NSLog(@"%@------------",error);
        
        
    }];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0 || section == 1) {
        return 1;
    }
    return self.dataArray.count +1;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        static NSString *cellIdentifier = @"OrderDetailTopTableViewCell";
        
        OrderDetailTopTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell == nil) {
            cell =  [[OrderDetailTopTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.order_NumLabel.text = [NSString stringWithFormat:@"订单编号：%@",self.order_num] ;
        cell.order_timeLabel.text =[NSString stringWithFormat:@"订单时间：%@", self.order_time] ;
        cell.adressLabel.text = [self.resultDic objectForKey:@"address"];
        NSString *userStr = [self.resultDic objectForKey:@"username"];
        NSString *telStr = [self.resultDic objectForKey:@"tel"];
        cell.user_telLabel.text = [NSString stringWithFormat:@"%@  %@",userStr,telStr];
        return cell;
    }
    if (indexPath.section == 1) {
        if (self.userArray.count == 1) {
            static NSString *cellIdentifier = @"DeliverymanDetailTableViewCell";
            
            DeliverymanDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell =  [[DeliverymanDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
           
            
            if ([roleName isEqualToString:@"库管"]) {
                cell.storekeeper_nameLabel.text = [NSString stringWithFormat:@"库管员：%@",[[self.userArray objectAtIndex:0]objectForKey:@"username"]];
            }
            if ([roleName isEqualToString:@"店长"]) {
                cell.storekeeper_nameLabel.text = [NSString stringWithFormat:@"店长：%@",[[self.userArray objectAtIndex:0]objectForKey:@"username"]];
            }
            
            cell.work_numAndphone_num.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:0]objectForKey:@"name"],[[self.userArray objectAtIndex:0]objectForKey:@"tel"]];
            return cell;
        }
        if (self.userArray.count == 2) {
            
            static NSString *cellIdentifier = @"ShopManangerDetailTableViewCell";
            
            ShopManangerDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell =  [[ShopManangerDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.storekeeperLabel.text = [NSString stringWithFormat:@"库管员：%@",[[self.userArray objectAtIndex:0]objectForKey:@"username"]];
            cell.store_workNum_phoneNumLabel.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:0]objectForKey:@"name"],[[self.userArray objectAtIndex:0]objectForKey:@"tel"]];
            cell.delivery_nameLabel.text = [NSString stringWithFormat:@"配送员：%@",[[self.userArray objectAtIndex:1]objectForKey:@"username"]];
            cell.delivery_workNum_phoneNumLabel.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:1]objectForKey:@"name"],[[self.userArray objectAtIndex:0]objectForKey:@"tel"]];
            
            return cell;
        }
        if (self.userArray.count == 3) {
            static NSString *cellIdentifier = @"SongdaDetailTableViewCell";
            
            SongdaDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell =  [[SongdaDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.storekeeperLabel.text = [NSString stringWithFormat:@"库管员：%@",[[self.userArray objectAtIndex:0]objectForKey:@"username"]];
            cell.store_workNum_phoneNumLabel.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:0]objectForKey:@"name"],[[self.userArray objectAtIndex:0]objectForKey:@"tel"]];
            cell.delivery_nameLabel.text = [NSString stringWithFormat:@"配送员：%@",[[self.userArray objectAtIndex:1]objectForKey:@"username"]];
            cell.delivery_workNum_phoneNumLabel.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:1]objectForKey:@"name"],[[self.userArray objectAtIndex:1]objectForKey:@"tel"]];
            cell.shop_manager_nameLabel.text = [NSString stringWithFormat:@"店长：%@",[[self.userArray objectAtIndex:2]objectForKey:@"username"]];
            cell.shop_manager_workNum_phoneNumLabel.text = [NSString stringWithFormat:@"工作编号:%@ 手机号:%@",[[self.userArray objectAtIndex:1]objectForKey:@"name"],[[self.userArray objectAtIndex:2]objectForKey:@"tel"]];
            return cell;
        }
    }
        if (indexPath.section == 2 ) {
        if (indexPath.row == 0) {
            static NSString *cellIdentifier = @"GoodsTableViewCell";
            
            GoodsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell =  [[GoodsTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }else{
            static NSString *cellIdentifier = @"GoodsListTableViewCell";
            
            GoodsListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell == nil) {
                cell =  [[GoodsListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            NSString *imageStr = [[self.dataArray objectAtIndex:indexPath.row - 1]objectForKey:@"propic"];
            NSString *nameStr = [[self.dataArray objectAtIndex:indexPath.row  -1]objectForKey:@"proname"];
            [ cell.productImage sd_setImageWithURL:[NSURL URLWithString:imageStr] placeholderImage:nil];
            cell.productName.text = nameStr;
            cell.product_num_priceLabel.text = [NSString stringWithFormat:@"数量：%@    价格:%@", [[self.dataArray objectAtIndex:indexPath.row - 1]objectForKey:@"pronum"],[[self.dataArray objectAtIndex:indexPath.row  -1]objectForKey:@"proprice"]];
            return cell;
        }

    }
    static NSString *cellIdentifier = @"UITableViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell =  [[OrderDetailTopTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
 
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 8;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
    return cell.frame.size.height;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
