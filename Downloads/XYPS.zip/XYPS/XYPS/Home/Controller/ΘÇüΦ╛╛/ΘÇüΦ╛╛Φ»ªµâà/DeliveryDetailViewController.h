//
//  DeliveryDetailViewController.h
//  XYPS
//
//  Created by apple on 16/11/14.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface DeliveryDetailViewController : BaseViewController
@property (nonatomic,copy)NSString *order_id;
@property (nonatomic,copy)NSString *order_num;
@property (nonatomic,copy)NSString *order_time;
@end
